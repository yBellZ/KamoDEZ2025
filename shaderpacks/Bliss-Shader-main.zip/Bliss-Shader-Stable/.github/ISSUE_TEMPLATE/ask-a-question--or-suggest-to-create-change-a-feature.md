---
name: Ask a question. Or suggest to create/change a feature
about: ask questions. or suggest changes
title: write your subject's topic here. DO NOT WRITE THE ENTIRE SUBJECT IN THIS TITLE.
labels: discussion
assignees: ''

---

[//]: # (
\
PLEASE READ THIS BEFORE WRITING YOUR SUBJECT!!!!
i have a discord server that is meant exactly for this! please join!
copy this discord invite link: https://discord.gg/8nVt56H9zH
\
If you do not have discord or just do not want to join, that is fine. write your question/suggestion with this instead )

write your question or suggestion here
