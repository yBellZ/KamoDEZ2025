---
name: Bug Report
about: Create a bug report so i can see if i can fix it.
title: write the topic of your issue. DO NOT WRITE THE ENTIRE ISSUE IN THIS TITLE
labels: bug
assignees: ''

---

### Describe the bug

[//]: # ( REPLACE THE TEXT BELOW THIS LINE WITH THE RELEVANT INFORMATION )
Describe the issue in as much detail as possible. 
- capturing footage of it with images or videos is preferred
- written descriptions ARE NOT PREFERRED. Shaderpack issues are inherently visual problems, written descriptions are usually very difficult to understand.

### Describe how your minecraft is set up

[//]: # ( REPLACE THE TEXT BELOW THIS LINE WITH THE RELEVANT INFORMATION )
- Include a screenshot of the in-game f3 debug overlay. This is the text on the screen that appears when you click the "f3" key on your keyboard.
- Please make sure it is fully visible. ensure that the GUI scale is set to 1x in minecrafts video settings. ensure that you DO NOT have mods that change the f3 overlay, such as "betterF3", or "cleanF3"

[//]: # ( IF YOU CANNOT PROVIDE THE INFORMATION ABOVE - please list this information below instead )
- What minecraft version you are playing (e.g 1.20.4 / 1.16.5 / 1.12)
- What shader loading mod you are using (e.g Iris / oculus / optifine)
- What version of the shader you are using (e.g Bliss v2.1.1 / Bliss-unstable / Bliss-stable)
- What GPU vendor you are using (e.g Apple / AMD / Nvidia / Intel)
- What operating system you are using (e.g Windows/ Linux / macOS)
- If you are using a special client for minecraft (e.g lunar / badlion / feather)
- If you are using any, list what additional mods you are using besides the ones required to use the shader (e.g distant horizons, physics mod)

### Describe how to reproduce, or cause the bug to happen

[//]: # ( REPLACE THE TEXT BELOW THIS LINE WITH THE RELEVANT INFORMATION )
- Show exactly how to make the bug appear if you can. Video footage is preferred.
- If a specific shader setting can make it start/stop bugging, please list what shader setting does that.
- Isolate the bug. some multiplayer servers cause issues on their own. in a newly made singleplayer world, with default/reset shader settings, show the exact steps to cause the bug
- if the bug is happening with content from a mod, list what mod, and what content of that mod it happens on.
